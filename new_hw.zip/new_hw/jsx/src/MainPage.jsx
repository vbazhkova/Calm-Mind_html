import React from 'react';

import { ActivityCard } from './components/ActivityCard';
import { MoodItem } from './components/MoodItem';
import { CalmMins } from './components/CalmMins';

import fallInImage from "./assets/fall-in-button.png"
import leafImage from "./assets/leaf-w.svg"
import game1Image from "./assets/game1.png"
import game2Image from "./assets/game2.png"
import game3Image from "./assets/game3.png"
import game4Image from "./assets/game4.png"

import mood1 from "./assets/mood1.svg"
import mood2 from "./assets/mood2.svg"
import mood3 from "./assets/mood3.svg"
import mood4 from "./assets/mood4.svg"
import mood5 from "./assets/mood5.svg"

import leafsvg from "./assets/leaf.svg"
import usersvg from "./assets/user.svg"
import homesvg from "./assets/home-w.svg"
import bottomLine from "./assets/buttom-line.svg"

export const MainPage = () => {
    return (
        <div>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no, viewport-fit=cover" />
        <div className="home">
              <div className="div">
                  <div className="spacing"><div className="x-spacing"></div></div>
                  <div className="spacing-size"><div className="x-spacing-2"></div></div>
                </div>
                <div className="content">
                  <div className="x-spacing-wrapper"><div className="x-spacing-3"></div></div>
                  <div className="typography"><div className="head">Hello Pashtet,</div></div>
                  <div className="div-wrapper"><div className="x-spacing-4"></div></div>
                  <div className="typography-2">
                    <p className="text-advice"></p>
                  </div>
                  <div className="x-spacing-wrapper"><div className="x-spacing-5"></div></div>
                  <CalmMins />
                  <div className="spacing-2"><div className="x-spacing-4"></div></div>
                  <div className="how-r-u">
                    <div className="typography-5"><p className="p">How do you feel today?</p></div>
                    <div className="frame">
                      <span className="integer">999</span>
                      <MoodItem propObject = {{ prop1: mood1 }} />
                      <span className="integer">1</span>
                      <MoodItem propObject = {{ prop1: mood2 }} />
                      <span className="integer">2</span>
                      <MoodItem propObject = {{ prop1: mood3 }} />
                      <span className="integer">3</span>
                      <MoodItem propObject = {{ prop1: mood4 }} />
                      <span className="integer">4</span>
                      <MoodItem propObject = {{ prop1: mood5 }} />
                      <span className="integer">5</span>
                    </div>
                  </div>
                  <div className="spacing-3"><div className="x-spacing-5"></div></div>
                  <div className="typography-6"><div className="text-3">Special for you</div></div>
                  <div className="div-wrapper"><div className="x-spacing-4"></div></div>
                  <ActivityCard propObject = {{ prop1: '4 of 25', prop2: game1Image }} />
                  <div className="div-wrapper"><div className="x-spacing-4"></div></div>
                  <ActivityCard propObject = {{ prop1: 'Matryoshka', prop2: game2Image }} />
                  <div className="div-wrapper"><div className="x-spacing-4"></div></div>
                  <ActivityCard propObject = {{ prop1: 'Cicero’s Method', prop2: game3Image }} />
                  <div className="div-wrapper"><div className="x-spacing-4"></div></div>
                  <ActivityCard propObject = {{ prop1: '3 of 60', prop2: game4Image }} />
                  <div className="div-wrapper"><div className="x-spacing-4"></div></div>
                </div>
              </div>
              <footer className="tabbar">
                <div className="tab-bar-home">
                  <div className="overlap-group">
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group">
                        <div className="rectangle"></div>
                        <div className="text-wrapper">HOME</div>
                        <div className="navigation-bar-icon"><img className="icon" src={homesvg} /></div>
                      </div>
                    </div>
                    <div className="icon-wrapper"><img className="img" src={usersvg} /></div>
                    <img className="navigation-bar-icon-2" src={leafsvg}/>
                    <img className="line" src={bottomLine} />
                  </div>
                </div>
              </footer>
        </div>              
    )
}