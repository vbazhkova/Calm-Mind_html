import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { MainPage } from "./MainPage";
import { LoginPage } from './login';

export const App = () => { 
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/main.html" element={<MainPage />} />
                <Route path="" element={<LoginPage />} />
            </Routes>
        </BrowserRouter>
    )
}