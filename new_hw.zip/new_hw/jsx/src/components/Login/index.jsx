import styles from './index.module.css'
import React, { useRef } from 'react';

import { useEffect } from 'react';

import loginImage from "../../assets/group.svg"
import passwordImage from "../../assets/lock.svg"

const LoginField = (props) => { 
   const { prop1 } = props.propObject;
   const inputRef = useRef(null)

   useEffect(() => {
      if (inputRef.current) {
         inputRef.current?.focus()
      }
   });

     return (
         <div className={styles.input}><div contentEditable={true} suppressContentEditableWarning={true} className={styles.login}>{prop1}</div></div>
     )
}

const PasswordField = (props) => { 
   const { prop1 } = props.propObject;
   const inputRef = useRef(null)

   useEffect(() => {
      if (inputRef.current) {
         inputRef.current?.focus()
      }
   });

     return (
         <div className={styles.input}><div contentEditable={true} suppressContentEditableWarning={true} className={styles.login}>{prop1}</div></div>
     )
}

export const Login = () => {
   return (
      <div className={styles.containerlogin}>
         <img className={styles.icon} src={loginImage} />
         <div className={styles.textgroup}>
           <LoginField propObject = {{ prop1: "Login" }}/>
         </div>
      </div>
   )
}

export const Password = () => {
   return (
      <div className={styles.containerlogin}>
         <img className={styles.icon} src={passwordImage} />
         <div className={styles.textgroup}>
           <PasswordField propObject = {{ prop1: "Password" }}/>
         </div>
      </div>
   )
}