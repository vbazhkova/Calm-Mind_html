import styles from './index.module.css'
import React from 'react';
import arrowImage  from '../../assets/arrow-back.svg'

export const ActivityCard = (props) => { 
    const { prop1, prop2 } = props.propObject;
     return (
      <div className={styles.cards}>
        <img className={styles.rectangle3} src={prop2} />
        <div className={styles.cell}>
          <div className={styles.textgroup}>
            <div className={styles.typography7}><div className={styles.typography8}>{prop1}</div></div>
          </div>
          <img className={styles.iconarrow} src={arrowImage} />
        </div>
      </div>
     )
}