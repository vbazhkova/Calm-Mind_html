import styles from './index.module.css'
import React from 'react';
import fallInImage from "../../assets/fall-in-button.png"
import leafImage from "../../assets/leaf-w.svg"

import { useState, useEffect } from 'react';

export const CalmMins = () => { 
    const [ cnt = 0, setCnt ] = useState(0)

    useEffect(() => {
        document.title = `You clicked ${cnt} times`;
    });

     return (
        <div className={styles.stat}>
        <img className={styles.button} src={fallInImage} />
        <div className={styles.stat2}>
          <div className={styles.overlap}><img className={styles.icon2} src={leafImage} onClick={() => setCnt(cnt+1)} /></div>
          <div className={styles.overlapgroup2}>
            <div className={styles.typographywrapper}><div className={styles.typography3}>of calm</div></div>
            <div className={styles.typography4}><div className={styles.text2}>{cnt} minutes</div></div>
          </div>
        </div>
      </div>
     )
}