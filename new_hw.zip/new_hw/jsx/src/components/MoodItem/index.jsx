import styles from './index.module.css'
import React from 'react';
import { handleIconClick } from '../../scripts/scripts-main.js'

export const MoodItem = (props) => { 
    const { prop1 } = props.propObject;

    const handleClick = (event) => {
        console.log('button clicked');
        handleIconClick(event)
      };

     return (
      <div className={styles.circle}>
        <img className={styles.icon} src={prop1} onClick={handleClick}/>
      </div>
     )
}