import styles from './index.module.css'
import googleImage  from '../../assets/google.svg'
import appleImage  from '../../assets/apple.svg'

export const GoogleImg = () => { 
     return (
        <div className={styles.button}>
            <img className={styles.googleb} src={googleImage} /> 
        </div>
     )
}

export const AppleImg = () => { 
    return (
       <div className={styles.button}>
            <img className={styles.googleb} src={appleImage} /> 
       </div>
    )
}