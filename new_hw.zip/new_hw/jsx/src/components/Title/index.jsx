import styles from './index.module.css'

export const Title = () => { 
    return (
        <div className={styles.title}>Create your <br />Account</div>
    )
}