import { Login } from "./components/Login"
import { Password } from "./components/Login"
import { Title } from "./components/Title"
import { GoogleImg } from "./components/OauthButton"
import { AppleImg } from "./components/OauthButton"
import loginImage from "./assets/group.svg"
import passwordImage from "./assets/lock.svg"
import eyeImage from "./assets/eye.svg" 
import lineImage from "./assets/line.svg"

export const LoginPage = () => { 
    return (
        <div>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no, viewport-fit=cover" />
        <div className="aut">
          <div className="div">
            <div className="safe-area">
              <div className="spacing"><div className="x-spacing" /></div>
              <div className="spacing-size"><div className="x-spacing-2" /></div>
            </div>
            <div className="content">
              <div className="x-spacing-wrapper"><div className="x-spacing-3" /></div>
              <div className="typography">
                <Title />
              </div>
              <div className="div-wrapper"><div className="x-spacing-4" /></div>
              <div className="input">
                <div className="cell">
                    <Login />
                </div>
              </div>
              <div className="spacing-2"><div className="x-spacing-5" /></div>
              <div className="cell-wrapper">
                <div className="cell-2">
                    {/* <Password/> */}
                    <Password />
                </div>
              </div>
              <div className="spacing-2"><div className="x-spacing-5" /></div>
              <div className="remember-me">
                <div className="checkboxes-wrapper">
                  <div className="checkboxes">
                    <div className="state-layer"><div className="container" /></div>
                  </div>
                </div>
                <div className="link-wrapper"><div className="link">Remember me</div></div>
              </div>
              <div className="spacing-2"><div className="x-spacing-5" /></div>
              <button className="button-login">
                <div className="typography-3"><div className="typography-4">Sign up</div></div>
              </button>
              <div className="div-wrapper"><div className="x-spacing-4" /></div>
              <div className="or">
                <div className="overlap-group">
                  <div className="typography-5"><div className="typography-6">or continue with</div></div>
                  <img className="line-left" src={lineImage} />
                  <img className="line-right" src={lineImage} />
                </div>
              </div>
              <div className="spacing-3"><div className="x-spacing-6" /></div>
              <div className="google-apple">
                <GoogleImg />
                <AppleImg />
              </div>
              <div className="x-spacing-wrapper"><div className="x-spacing-3" /></div>
              <div className="sec-text-wrapper">
                <p className="sec-text">
                  <span className="span">Already have an account?&nbsp;&nbsp; </span>
                  <span className="text-wrapper-2">Sign in</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
}