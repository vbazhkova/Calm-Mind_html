import React from 'react'
import ReactDOM from 'react-dom/client'
import { App } from './App.jsx'
import './styles/index.css'
import './styles/style.css'
import './scripts/scripts.js'
import './styles/main.css'
import './scripts/scripts-main.js'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)